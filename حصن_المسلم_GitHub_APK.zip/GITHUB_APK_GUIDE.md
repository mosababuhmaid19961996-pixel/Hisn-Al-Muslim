# حصن المسلم — بناء APK عبر GitHub

## الطريقة الأسهل

1. أنشئ مستودعًا جديدًا في GitHub، مثل:
   `hisn-al-muslim`
2. ارفع **محتويات هذا المجلد** إلى المستودع.
3. تأكد أن ملف البناء موجود هنا:
   `.github/workflows/android.yml`
4. افتح تبويب **Actions** في GitHub.
5. اختر **Build Android APK**.
6. اضغط **Run workflow**.
7. بعد انتهاء البناء، افتح نتيجة التشغيل.
8. من قسم **Artifacts** نزّل:
   `Hisn-Al-Muslim-APK`
9. فك الضغط وستجد:
   `app-debug.apk`
10. انقل APK إلى هاتف Android وثبّته.

## ملاحظات

- هذا Workflow يبني نسخة Debug للتثبيت والاختبار.
- للنشر في Google Play نحتاج لاحقًا إلى إعداد توقيع Release وبناء AAB.
- لا تضع كلمات مرور أو مفاتيح توقيع داخل المستودع.
- GitHub Actions هو الذي يوفر بيئة Android ويقوم بالبناء تلقائيًا.
