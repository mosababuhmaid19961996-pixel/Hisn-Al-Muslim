# حصن المسلم — GitHub APK

هذا المشروع مجهز للبناء التلقائي عبر GitHub Actions.

ملف Workflow:
`.github/workflows/android.yml`

راجع `GITHUB_APK_GUIDE.md` للخطوات.
